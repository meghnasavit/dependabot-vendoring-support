  // Make it compatible with previous version.
  jStat.jStat = jStat;

  return jStat;
});
