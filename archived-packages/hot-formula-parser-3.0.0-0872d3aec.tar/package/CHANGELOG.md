All releases are described at https://github.com/handsontable/formula-parser/releases
